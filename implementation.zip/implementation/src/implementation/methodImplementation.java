package implementation;
import java.util.Scanner;

/**
 *
 * @author nafha
 */
public class methodImplementation {
    public void nyot(){
        int age, birth, current;
        String choice;
        Scanner input = new Scanner(System.in);

        do {
            // User input for birth year and current year
            System.out.println("Enter your birthyear:");
            birth = input.nextInt();
            System.out.println("Enter the current year:");
            current = input.nextInt();

            // Calculate user age
            age = current - birth;

            // Display user's age
            System.out.println("Age: " + age);

            input.nextLine();  // Consume newline left after nextInt

            // Ask if user wants to exit
            System.out.print("\nDo you want to exit? (yes/no): ");
            choice = input.nextLine();
        } while (!choice.equalsIgnoreCase("yes"));

        System.out.println("Thank you for using the system.");
    }
}
    