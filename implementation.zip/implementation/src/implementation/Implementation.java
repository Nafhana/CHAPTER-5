package implementation;

public class Implementation {
    public static void main(String[] args) {
        // Create an instance of AgeCalculator and call the nyot method
        methodImplementation mymethodImplementation = new methodImplementation();
        mymethodImplementation.nyot();
    }
}