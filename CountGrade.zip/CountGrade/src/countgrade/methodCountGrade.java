package countgrade;
import java.util.Scanner;

/**
 *
 * @author nafha
 */
public class methodCountGrade {
    public void nyot(){
        Scanner input = new Scanner(System.in);

        int countA = 0, countB = 0, countC = 0, countD = 0, countE = 0;
        String choice;
        char grade;

        do {
        // Loop to collect each student's test mark
        for (int i = 1; i <= 10; i++) {
            System.out.print("Enter the mark for student " + i + ": ");
            int mark = input.nextInt();

            // Determine the grade based on the mark and count it
            if (mark >= 70 && mark <= 100) {
                grade = 'A';
                countA++;
            } else if (mark >= 60 && mark <= 69) {
                grade = 'B';
                countB++;
            } else if (mark >= 50 && mark <= 59) {
                grade = 'C';
                countC++;
            } else if (mark >= 45 && mark <= 49) {
                grade = 'D';
                countD++;
            } else {
                grade = 'E';
                countE++;
            }
        }

        // Output the count of each grade
        System.out.println("\nNumber of students who got A: " + countA);
        System.out.println("Number of students who got B: " + countB);
        System.out.println("Number of students who got C: " + countC);
        System.out.println("Number of students who got D: " + countD);
        System.out.println("Number of students who got E: " + countE);
        
        input.nextLine();  // Consume newline left after nextInt

            // Ask if user wants to exit
            System.out.print("\nDo you want to exit? (yes/no): ");
            choice = input.nextLine();
        } while (!choice.equalsIgnoreCase("yes"));

        System.out.println("Thank you for using the system.");
    }
}
  