package countgrade;

public class CountGrade {
    public static void main(String[] args) {
        // Create an instance of GradeCounter and call the nyot method
        methodCountGrade mymethodCountGrade = new methodCountGrade();
        mymethodCountGrade.nyot();
    }
}