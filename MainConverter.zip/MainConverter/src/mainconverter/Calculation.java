/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainconverter;

/**
 *
 * @author nafha
 */
public class Calculation {

    // Method for mass
    public float mass(float num) {
        return num / 1000;
    }

    // Method for distance
    public float distance(float num) {
        return num / 1000;
    }

    // Method for temperature
    public float temperature(float num) {
        return (num * 9 / 5) + 32;
    }
}
