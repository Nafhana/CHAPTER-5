
package mainconverter;

import java.util.Scanner;

/**
 *
 * @author nafha
 */
public class MainConverter {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        // Objects for Display and Calculation
        Display mydisplay = new Display();
        Calculation mycalculation = new Calculation();

        Scanner input = new Scanner(System.in);

        // ask user to choose a converter
        mydisplay.nyot();
        int conv = input.nextInt();

        // Perform calculation with the input number
        switch (conv) {
            case 1:
                mydisplay.nyott();
                float num = input.nextFloat();
                float mass = mycalculation.mass(num);
                mydisplay.nyoot(num + "g = " + mass + "kg");
                break;
            case 2:
                mydisplay.nyott();
                num = input.nextFloat();
                float dis = mycalculation.distance(num);
                mydisplay.nyoot(num + "m = " + dis + "km");
                break;
            case 3:
                mydisplay.nyott();
                num = input.nextFloat();
                float temp = mycalculation.temperature(num);
                mydisplay.nyoot(num + "C = " + temp + "F");
                break;
            default:
                mydisplay.heh();
                break;
        }
    }
}
