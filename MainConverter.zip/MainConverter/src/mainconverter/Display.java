/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainconverter;

/**
 *
 * @author nafha
 */
public class Display {

    // Method to display menu
    public void nyot() {
        System.out.println("-Converter Available-\n");
        System.out.println("1. Mass converter (g - kg)");
        System.out.println("2. Distance converter (m - km)");
        System.out.println("3. Temperature converter (Celsius - Fahrenheit)");
        System.out.println("\nChoose the converter (1-3): ");
    }

    // Method for number input
    public void nyott() {
        System.out.println("Insert number to convert: ");
    }

    // Method to display the result
    public void nyoot(String result) {
        System.out.println("\n" + result);
    }

    // Method for invalid options
    public void heh() {
        System.out.println("\nInvalid option.");
    }
}


