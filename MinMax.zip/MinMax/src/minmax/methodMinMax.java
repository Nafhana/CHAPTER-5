package minmax;
import java.util.Scanner;


/**
 *
 * @author nafha
 */
public class methodMinMax {
    public void nyot(){
        String choice;
        Scanner input = new Scanner(System.in);

        do {
            double number1, number2, number3;

            System.out.print("Enter first integer: ");
            number1 = input.nextDouble();
            System.out.print("Enter second integer: ");
            number2 = input.nextDouble();
            System.out.print("Enter third integer: ");
            number3 = input.nextDouble();

            double max = maximum(number1, number2, number3);
            System.out.println("The maximum value is: " + max);
            double min = minimum(number1, number2, number3);
            System.out.println("The minimum value is: " + min);

            input.nextLine(); 

            System.out.print("\nDo you want to exit? (yes/no): ");
            choice = input.nextLine();
        } while (!choice.equalsIgnoreCase("yes"));

        System.out.println("Thank you for using the system.");
    }

    public double maximum(double x, double y, double z) {
        return Math.max(x, Math.max(y, z));
    }

    public double minimum(double x, double y, double z) {
        return Math.min(x, Math.min(y, z));
    }
}