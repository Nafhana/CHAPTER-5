package minmax;

public class MinMax {
    public static void main(String[] args) {
        //call the nyot method
        methodMinMax mymethodMinMax = new methodMinMax();
        mymethodMinMax.nyot();
    }
}

