
package mainhighavg;

/**
 *
 * @author nafha
 */
public class Display {

    public void StudentMarksInput(int studentNumber) {
        System.out.println("Enter marks for Student " + studentNumber + ":");
    }

    public void TestInput(int testNumber) {
        System.out.print("Test " + testNumber + ": ");
    }

    public void AverageMark(int studentNumber, double average) {
        System.out.printf("Average mark for Student %d: %.2f%n", studentNumber, average);
        System.out.println();
    }

    public void HighAverage(double maxAverage) {
        System.out.printf("The highest average : %.2f%n", maxAverage);
    }
}
