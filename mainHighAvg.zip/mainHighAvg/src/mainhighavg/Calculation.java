
package mainhighavg;

/**
 *
 * @author nafha
 */
public class Calculation {

    // Mfind the maximum average from array
    public double findMax(double[] averages) {
        double max = averages[0];
        for (int i = 1; i < averages.length; i++) {
            if (averages[i] > max) {
                max = averages[i];
            }
        }
        return max;
    }
}
