package mainhighavg;
import java.util.Scanner;

/**
 *
 * @author nafha
 */
public class MainHighAvg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        Display mydisplay = new Display();
        Calculation mycalculation = new Calculation();

        int students = 3;
        int tests = 3;
        double total, average;
        // Store averages of students
        double[] averages = new double[students]; 

        for (int x = 1; x <= students; x++) {
            total = 0;

            // marks for each test
            mydisplay.StudentMarksInput(x);
            for (int test = 1; test <= tests; test++) {
                mydisplay.TestInput(test);
                int mark = scanner.nextInt();
                total += mark; // Total all marks
            }

            // Calculate average
            average = total / tests;
            averages[x - 1] = average;

            // Display the average for each student
            mydisplay.AverageMark(x, average);
        }

        // Find the highest average
        double max = mycalculation.findMax(averages);

        mydisplay.HighAverage(max);

        scanner.close();
    }
}
